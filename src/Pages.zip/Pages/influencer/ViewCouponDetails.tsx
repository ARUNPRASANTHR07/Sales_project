import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { HomeIcon } from "@heroicons/react/24/solid";
import Darkmode from "../../Components/Darkmode";
import { Button } from "../../Components/Button";
import Grid from "../../Components/grid";
import Loader from "../../Components/Loading";
import apiClient from "../../api/apiClient";
import SuccessPopup from '../../Components/SuccessPopup';
import ErrorPopup from '../../Components/ErrorMsgpopup';
import axios, { AxiosError } from "axios";
import HierarchyComponent from "../../Components/Hierarchy";
import InfluencerComponent from "../../Components/InfluencerComponent";

interface SearchCriteria {
    StateCode: string;
    RegionCode: string;
    ZoneCode: string;
    SectorCode: string;
    AreaCode: string;
    Mobile: string;
}

const CouponDetails: React.FC = () => {
    const navigate = useNavigate();

    const [criteria, setCriteria] = useState<SearchCriteria>({
        StateCode: "",
        RegionCode: "",
        ZoneCode: "",
        SectorCode: "",
        AreaCode: "",
        Mobile: "",
    });

    /* MAIN DROPDOWNS */
    const [stateOpts, setStateOpts] = useState<any[]>([]);
    const [regionOpts, setRegionOpts] = useState<any[]>([]);
    const [zoneOpts, setZoneOpts] = useState<any[]>([]);
    const [sectorOpts, setSectorOpts] = useState<any[]>([]);
    const [areaOpts, setAreaOpts] = useState<any[]>([]);
    const [successMsg, setSuccessMsg] = useState(false);
    const [errMsg, setErrMsg] = useState(false);
    const [errorMessage, seterrorMessage] = useState("");

    /* MASTER LISTS (TEMP STORAGE FROM INIT) */
    const [regionML, setRegionML] = useState<any[]>([]);
    const [zoneML, setZoneML] = useState<any[]>([]);
    const [sectorML, setSectorML] = useState<any[]>([]);
    const [areaML, setAreaML] = useState<any[]>([]);

    const [mobileList, setMobileList] = useState<string[]>([]);
    const [rows, setRows] = useState<any[]>([]);
    const [columns, setColumns] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [Marketing_Hier, setMarketing_Hier] = useState<Array<any>>([]);
    const [staticData, setStaticData] = useState<Array<any>>([]);
    const [InfluencerDetails, setInfluencerDetails] = useState<any[]>([]);
    const [PreviousDrillHierarchy, setPreviousDrillHierarchy] = useState<any[]>([]);

    const [level, setLevel] = useState<
        "STATE" | "REGION" | "ZONE" | "SECTOR" | "AREA" | "INFLUENCER"
    >("STATE");

    const [selectedHierarchy, setSelectedHierarchy] = useState({
        State: "",
        Region: "",
        Zone: "",
        Sector: "",
    });

    /* INIT LOAD */
    const fetchInit = async () => {
        setLoading(true);
        try {
            const res = await apiClient.post("/common", {
                Usercontext: JSON.parse(localStorage.getItem("activeUserInfo") || "{}"),
                servicename: "CouponInit",
                JsonValue: {},
            });

            console.log("Init API response:", res);

            if (res.data.success) {
                setStateOpts(res.data.data[0]);
                setRegionML(res.data.data[1]);
                setZoneML(res.data.data[2]);
                setSectorML(res.data.data[3]);
                setAreaML(res.data.data[4]);
                setMarketing_Hier(res.data.data[5]);

                setStaticData(res.data.data[6] || []);

            }


        }
        catch (err) {
            console.error("Error submitting KPI data:", err);
            setLoading(false);
            setErrMsg(true);

            const axiosError = err as any;
            const originalError = axiosError?.response?.data?.message || "An unknown error occurred";
            seterrorMessage(originalError.originalError.info.message || "An unknown error occurred");

        }
        finally {
            setLoading(false);
        }
    };

    useEffect(() => {

        fetchInit();
    }, []);


    // useEffect(() => {
    //     if (Marketing_Hier && Marketing_Hier.length > 0) {
    //         const uniqueStates = Array.from(
    //             new Map(
    //                 Marketing_Hier.map(item => [
    //                     item.State_Code, // key for uniqueness
    //                     {
    //                         value: item.State_Code,
    //                         label: item.State,
    //                     },
    //                 ])
    //             ).values()
    //         );

    //         setStateOpts(uniqueStates);
    //     }
    // }, [Marketing_Hier]);


    // /* CASCADING FILTERS */

    // const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>): void => {
    //     const val = e.target.value;

    //     setCriteria({
    //         StateCode: val,
    //         RegionCode: "",
    //         ZoneCode: "",
    //         SectorCode: "",
    //         AreaCode: "",
    //         Mobile: criteria.Mobile,
    //     });
    //     console.log("Selected State Code:", e.target.value);
    //     setZoneOpts([]);
    //     setSectorOpts([]);
    //     setAreaOpts([]);
    //     const filteredRegions = Array.from(
    //         new Map(
    //             Marketing_Hier
    //                 .filter(item => item.State_Code === val)
    //                 .map(item => [
    //                     item.State_Code + item.Region_Code, // unique combo key
    //                     {
    //                         label: item.Region,
    //                         value: item.Region_Code,
    //                     }
    //                 ])
    //         ).values()
    //     );


    //     setRegionOpts([...filteredRegions, { label: 'All', value: '00' }
    //     ]);

    // };

    // const handleRegionChange = (e: any) => {
    //     const val = e.target.value;

    //     setCriteria(prev => ({ ...prev, RegionCode: val, ZoneCode: "", SectorCode: "", AreaCode: "" }));
    //     const filteredZones = Array.from(
    //         new Map(
    //             Marketing_Hier
    //                 .filter(item => (item.State_Code === criteria.StateCode) &&
    //                     (item.Region_Code === val))
    //                 .map(item => [
    //                     item.Zone_Code + item.Region_Code + item.State_Code, // unique key
    //                     {
    //                         label: item.Zone,
    //                         value: item.Zone_Code,
    //                     },
    //                 ])
    //         ).values()
    //     );


    //     setZoneOpts([
    //         ...filteredZones, { label: 'All', value: '00' }]);
    //     setSectorOpts([]);
    //     setAreaOpts([]);
    // };

    // const handleZoneChange = (e: any) => {
    //     const val = e.target.value;

    //     setCriteria(prev => ({ ...prev, ZoneCode: val, SectorCode: "", AreaCode: "" }));

    //     const filteredSector = Array.from(
    //         new Map(
    //             Marketing_Hier
    //                 .filter(item => (item.State_Code === criteria.StateCode) &&
    //                     (item.Region_Code === criteria.RegionCode) && (item.Zone_Code === val))
    //                 .map(item => [
    //                     item.Sector_Code + item.Zone_Code + item.Region_Code + item.State_Code, // unique key
    //                     {
    //                         label: item.Sector,
    //                         value: item.Sector_Code,
    //                     },
    //                 ])
    //         ).values()
    //     );

    //     setSectorOpts(
    //         [...filteredSector, { label: 'All', value: '00' }]
    //     )
    //     setAreaOpts([]);
    // };

    // const handleSectorChange = (e: any) => {
    //     const val = e.target.value;

    //     setCriteria(prev => ({ ...prev, SectorCode: val, AreaCode: "" }));
    //     const filteredArea = Array.from(
    //         new Map(
    //             Marketing_Hier
    //                 .filter(item => (item.State_Code === criteria.StateCode) &&
    //                     (item.Region_Code === criteria.RegionCode) && (item.Zone_Code === criteria.ZoneCode)
    //                     && (item.Sector_Code === val))
    //                 .map(item => [
    //                     item.Area_Code + item.Sector_Code + item.Zone_Code + item.Region_Code + item.State_Code, // unique key
    //                     {
    //                         label: item.Area,
    //                         value: item.Area_Code,
    //                     },
    //                 ])
    //         ).values()
    //     );

    //     setAreaOpts(
    //         [...filteredArea, { label: 'All', value: '00' }]
    //     )

    // };

    // /* SEARCH */
    // const handleSearch = async () => {
    //     setLoading(true);
    //     try {
    //         const res = await apiClient.post("/common", {
    //             Usercontext: JSON.parse(localStorage.getItem("activeUserInfo") || "{}"),
    //             servicename: "CouponSearch",
    //             JsonValue: criteria,
    //         });

    //         if (res.data.success) {
    //             setRows(res.data.data[0]);
    //         }
    //     } catch (err: unknown) {
    //         console.error("Full Axios error:", err);

    //         if (axios.isAxiosError(err)) {
    //             console.log("Backend error response:", err.response?.data);

    //             const message =
    //                 err.response?.data?.message ||
    //                 err.message ||
    //                 "Something went wrong";

    //             seterrorMessage(message);
    //             setErrMsg(true);
    //         } else {
    //             console.log("Unknown error:", err);
    //             seterrorMessage("Unexpected error occurred");
    //             setErrMsg(true);
    //         }
    //     }
    //     finally {
    //         setLoading(false);
    //     }
    // };

    useEffect(() => {

        const stateWise = Object.values(
            staticData.reduce((acc: any, item: any) => {
                if (!acc[item.State]) {
                    acc[item.State] = {
                        State: item.State,
                        InfluencerCount: 0,
                        ScannedAmount: 0,
                        RedeemedAmount: 0,
                        BalanceAmount: 0,
                    };
                }

                acc[item.State].InfluencerCount += item.InfluencerCount;
                acc[item.State].ScannedAmount += item.ScannedAmount;
                acc[item.State].RedeemedAmount += item.RedeemedAmount;
                acc[item.State].BalanceAmount += item.BalanceAmount;

                return acc;
            }, {})
        );

        setRows(stateWise);
    }, [staticData]);

    const handleDrill = (row: any) => {
        if (level === "STATE") {
            setSelectedHierarchy({ ...selectedHierarchy, State: row.State });
            setLevel("REGION");
            loadRegionWise(row.State);
        }
        else if (level === "REGION") {
            setSelectedHierarchy({ ...selectedHierarchy, Region: row.Region });
            setLevel("ZONE");
            loadZoneWise(selectedHierarchy.State, row.Region);
        }
        else if (level === "ZONE") {
            setSelectedHierarchy({ ...selectedHierarchy, Zone: row.Zone });
            setLevel("SECTOR");
            loadSectorWise(selectedHierarchy.State, selectedHierarchy.Region, row.Zone);
        }
        else if (level === "SECTOR") {
            setSelectedHierarchy({ ...selectedHierarchy, Sector: row.Sector });
            setLevel("AREA");
            loadAreaWise(
                selectedHierarchy.State,
                selectedHierarchy.Region,
                selectedHierarchy.Zone,
                row.Sector
            );
        }
        else if (level === "AREA") {

            const selectedArea = row.Area;

            setSelectedHierarchy(prev => ({
                ...prev,
                Area: selectedArea
            }));

            // 🔥 TRIGGER API HERE
            fetchAreaDetails(
                selectedHierarchy.State,
                selectedHierarchy.Region,
                selectedHierarchy.Zone,
                selectedHierarchy.Sector,
                selectedArea
            );
        }
    };

    const loadRegionWise = (state: string) => {
        const regionWise = Object.values(
            staticData
                .filter(x => x.State === state)
                .reduce((acc: any, item: any) => {
                    if (!acc[item.Region]) {
                        acc[item.Region] = {
                            State: state,
                            Region: item.Region,
                            InfluencerCount: 0,
                            ScannedAmount: 0,
                            RedeemedAmount: 0,
                            BalanceAmount: 0,
                        };
                    }

                    acc[item.Region].InfluencerCount += item.InfluencerCount;
                    acc[item.Region].ScannedAmount += item.ScannedAmount;
                    acc[item.Region].RedeemedAmount += item.RedeemedAmount;
                    acc[item.Region].BalanceAmount += item.BalanceAmount;

                    return acc;
                }, {})
        );

        setRows(regionWise);
    };
    const loadZoneWise = (state: string, region: string) => {
        const zoneWise = Object.values(
            staticData
                .filter(
                    x =>
                        x.State === state &&
                        x.Region === region
                )
                .reduce((acc: any, item: any) => {
                    if (!acc[item.Zone]) {
                        acc[item.Zone] = {
                            State: state,
                            Region: region,
                            Zone: item.Zone,
                            InfluencerCount: 0,
                            ScannedAmount: 0,
                            RedeemedAmount: 0,
                            BalanceAmount: 0,
                        };
                    }

                    acc[item.Zone].InfluencerCount += item.InfluencerCount;
                    acc[item.Zone].ScannedAmount += item.ScannedAmount;
                    acc[item.Zone].RedeemedAmount += item.RedeemedAmount;
                    acc[item.Zone].BalanceAmount += item.BalanceAmount;

                    return acc;
                }, {})
        );

        setRows(zoneWise);
    };
    const loadSectorWise = (
        state: string,
        region: string,
        zone: string
    ) => {
        const sectorWise = Object.values(
            staticData
                .filter(
                    x =>
                        x.State === state &&
                        x.Region === region &&
                        x.Zone === zone
                )
                .reduce((acc: any, item: any) => {
                    if (!acc[item.Sector]) {
                        acc[item.Sector] = {
                            State: state,
                            Region: region,
                            Zone: zone,
                            Sector: item.Sector,
                            InfluencerCount: 0,
                            ScannedAmount: 0,
                            RedeemedAmount: 0,
                            BalanceAmount: 0,
                        };
                    }

                    acc[item.Sector].InfluencerCount += item.InfluencerCount;
                    acc[item.Sector].ScannedAmount += item.ScannedAmount;
                    acc[item.Sector].RedeemedAmount += item.RedeemedAmount;
                    acc[item.Sector].BalanceAmount += item.BalanceAmount;

                    return acc;
                }, {})
        );

        setRows(sectorWise);
    };
    const loadAreaWise = (
        state: string,
        region: string,
        zone: string,
        sector: string
    ) => {
        const areaWise = Object.values(
            staticData
                .filter(
                    x =>
                        x.State === state &&
                        x.Region === region &&
                        x.Zone === zone &&
                        x.Sector === sector
                )
                .reduce((acc: any, item: any) => {
                    if (!acc[item.Area]) {
                        acc[item.Area] = {
                            State: state,
                            Region: region,
                            Zone: zone,
                            Sector: sector,
                            Area: item.Area,
                            InfluencerCount: 0,
                            ScannedAmount: 0,
                            RedeemedAmount: 0,
                            BalanceAmount: 0,
                        };
                    }

                    acc[item.Area].InfluencerCount += item.InfluencerCount;
                    acc[item.Area].ScannedAmount += item.ScannedAmount;
                    acc[item.Area].RedeemedAmount += item.RedeemedAmount;
                    acc[item.Area].BalanceAmount += item.BalanceAmount;

                    return acc;
                }, {})
        );

        setRows(areaWise);
    };

    const handleBack = () => {
        if (level === "INFLUENCER") {
            setLevel("AREA");
            loadAreaWise(
                selectedHierarchy.State,
                selectedHierarchy.Region,
                selectedHierarchy.Zone,
                selectedHierarchy.Sector
            );
        }
        if (level === "AREA") {
            setLevel("SECTOR");
            loadSectorWise(
                selectedHierarchy.State,
                selectedHierarchy.Region,
                selectedHierarchy.Zone
            );
        }
        else if (level === "SECTOR") {
            setLevel("ZONE");
            loadZoneWise(
                selectedHierarchy.State,
                selectedHierarchy.Region
            );
        }
        else if (level === "ZONE") {
            setLevel("REGION");
            loadRegionWise(selectedHierarchy.State);
        }
        else if (level === "REGION") {
            setLevel("STATE");

            // Reload state level summary
            const stateWise = Object.values(
                staticData.reduce((acc: any, item: any) => {
                    if (!acc[item.State]) {
                        acc[item.State] = {
                            State: item.State,
                            InfluencerCount: 0,
                            ScannedAmount: 0,
                            RedeemedAmount: 0,
                            BalanceAmount: 0,
                        };
                    }

                    acc[item.State].InfluencerCount += item.InfluencerCount;
                    acc[item.State].ScannedAmount += item.ScannedAmount;
                    acc[item.State].RedeemedAmount += item.RedeemedAmount;
                    acc[item.State].BalanceAmount += item.BalanceAmount;

                    return acc;
                }, {})
            );

            setRows(stateWise);
        }
    };

    const fetchAreaDetails = async (
        state: string,
        region: string,
        zone: string,
        sector: string,
        area: string
    ) => {


        // 🔥 API CALL TO FETCH INFLUENCER LEVEL Only If InfluencerDetails length is 0 or previous hier is differ from current seledted hierarchy
        if (InfluencerDetails.length === 0 || !PreviousDrillHierarchy.some(h =>
            h.state === state && h.region === region && h.zone === zone && h.sector === sector && h.area === area
        )) {
            try {
                setLoading(true);

                const res = await apiClient.post("/common", {
                    Usercontext: JSON.parse(localStorage.getItem("activeUserInfo") || "{}"),
                    servicename: "CouponAreaDetails",  // create backend service
                    JsonValue: {
                        State: state,
                        Region: region,
                        Zone: zone,
                        Sector: sector,
                        Area: area
                    }
                });

                if (res.data.success) {
                    setRows(res.data.data[0]);   // influencer level data
                    setInfluencerDetails(res.data.data[0]); // additional details if needed
                    setLevel("INFLUENCER");     // new level
                    setPreviousDrillHierarchy([]); // clear drill history on new drill 
                    setPreviousDrillHierarchy((prev) => [...prev, { state, region, zone, sector, area }]); // store drill path
                }

            } catch (err) {
                console.error("Area API error:", err);
                setErrMsg(true);
                seterrorMessage("Failed to load area details");
            } finally {
                setLoading(false);
            }
        }
        else {

            console.log("Using cached influencer details for:", { state, region, zone, sector, area }, PreviousDrillHierarchy);
            if (InfluencerDetails.length > 0) {
                setLevel("INFLUENCER");
                setRows(InfluencerDetails);
            }
            else {
                setErrMsg(true);
                seterrorMessage("No influencer details available kindly refresh the screen");
            }
        }
    };

    return (
        <div className="min-h-screen dark:bg-gray-900 p-4 text-gray-900 dark:text-white">
            <div className="flex justify-between mb-4">
                <h1 className="text-2xl font-bold">Coupon Details</h1>
                <div className="flex gap-3">
                    <Darkmode />
                    <Button onClick={() => navigate("/Mainpage")}>
                        <HomeIcon className="h-5 w-5" />
                    </Button>
                </div>
            </div>

            {/*  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-4">

                <div>
                    <label className="block mb-2 font-small">State</label>
                    <select value={criteria.StateCode} onChange={handleStateChange}
                        className="max-w-xs w-[calc(100%-20%)] h-8 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <option value="">Select State</option>
                        {stateOpts.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}

                    </select>
                </div>

                <div>
                    <label className="block mb-2 font-small">Region</label>
                    <select value={criteria.RegionCode} onChange={handleRegionChange}
                        className="max-w-xs w-[calc(100%-20%)] h-8 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <option value="">Select Region</option>
                        {regionOpts.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                    </select>
                </div>

                <div>
                    <label className="block mb-2 font-small">Zone</label>
                    <select value={criteria.ZoneCode} onChange={handleZoneChange}
                        className="max-w-xs w-[calc(100%-20%)] h-8 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <option value="">Select Zone</option>
                        {zoneOpts.map(z => <option key={z.value} value={z.value}>{z.label}</option>)}
                    </select>
                </div>

                <div>
                    <label className="block mb-2 font-small">Sector</label>
                    <select value={criteria.SectorCode} onChange={handleSectorChange}
                        className="max-w-xs w-[calc(100%-20%)] h-8 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <option value="">Select Sector</option>
                        {sectorOpts.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                    </select>
                </div>

                <div>
                    <label className="block mb-2 font-small">Area</label>
                    <select value={criteria.AreaCode}
                        onChange={e => setCriteria(prev => ({ ...prev, AreaCode: e.target.value }))}
                        className="max-w-xs w-[calc(100%-20%)] h-8 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <option value="">Select Area</option>
                        {areaOpts.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
                    </select>
                </div>

                <div>
                    <label className="block mb-2 font-small">Influencer Mobile</label>
                    <input list="mobileList" placeholder="Search Mobile"
                        value={criteria.Mobile}
                        onChange={e => setCriteria(prev => ({ ...prev, Mobile: e.target.value }))}
                        className="max-w-xs w-[calc(100%-20%)] h-8 border rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white px-2" />
                    <datalist id="mobileList">
                        {mobileList.map(m => <option key={m} value={m} />)}
                    </datalist>
                </div>

            </div>

            <Button onClick={handleSearch}>Search</Button> */}

            {loading && <Loader loading />}

            {/* <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                {rows.map((row, i) =>
                    row.InfluencerMobile ? (
                        <InfluencerComponent key={i} row={row} />
                    )
                        : (
                            <HierarchyComponent key={i} row={row} />
                        )
                )}
            </div> */}
            {level !== "STATE" && (
                <div className="mb-4">
                    <Button onClick={handleBack}>
                        ← Back
                    </Button>
                </div>
            )}

            {level === "INFLUENCER" ? (
                <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                    {rows.map((row, i) => (
                        <InfluencerComponent key={i} row={row} />
                    ))}
                </div>
            ) : (
                <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                    {rows.map((row, i) => (
                        <div key={i} onClick={() => handleDrill(row)} className="cursor-pointer">
                            <HierarchyComponent row={row} />
                        </div>
                    ))}
                </div>
            )}

            {
                successMsg && (
                    <SuccessPopup
                        message={"Data Saved successfully!"}
                        isopen={true}
                        onClose={() => setSuccessMsg(false)}
                    />
                )
            }
            {
                errMsg && (
                    <ErrorPopup
                        message={errorMessage}
                        isopen={true}
                        onClose={() => setErrMsg(false)}
                    />
                )
            }
        </div>
    );
};

export default CouponDetails;
